from django.shortcuts import render, get_object_or_404, redirect
from django.contrib import messages
from .models import Producto, Categoria, Pedido, ImagenReferencia, Comentario

def catalogo(request):
    productos = Producto.objects.all()
    categorias = Categoria.objects.all()
    
    categoria_seleccionada = request.GET.get('categoria')
    busqueda = request.GET.get('q')

    if categoria_seleccionada:
        productos = productos.filter(categoria__slug=categoria_seleccionada)

    if busqueda:
        productos = productos.filter(nombre__icontains=busqueda)

    destacados = Producto.objects.filter(destacado=True)

    context = {
        'productos': productos,
        'categorias': categorias,
        'productos_destacados': destacados
    }
    return render(request, 'catalogo.html', context)

def producto_detalle(request, slug):
    producto = get_object_or_404(Producto, slug=slug)

    if request.method == 'POST':
        nombre = request.POST.get('nombre')
        texto = request.POST.get('texto')

        if nombre and texto:
            Comentario.objects.create(
                producto=producto,
                nombre=nombre,
                texto=texto
            )
            return redirect('producto_detalle', slug=slug)

    comentarios = producto.comentarios.all().order_by('-fecha')

    return render(request, 'producto_detalle.html', {
        'producto': producto, 
        'comentarios': comentarios
    })

def solicitar_pedido(request, producto_id=None):
    producto_inicial = None
    if producto_id:
        producto_inicial = get_object_or_404(Producto, pk=producto_id)

    if request.method == 'POST':
        nombre = request.POST.get('nombre_cliente')
        descripcion = request.POST.get('descripcion_solicitada')

        if not nombre or not descripcion:
            messages.error(request, "Faltan datos obligatorios")
            return redirect(request.path)

        producto_final = producto_inicial
        id_referencia = request.POST.get('producto_referencia')
        
        if id_referencia:
            producto_final = Producto.objects.filter(pk=id_referencia).first()

        nuevo_pedido = Pedido.objects.create(
            nombre_cliente=nombre,
            email_cliente=request.POST.get('email_cliente'),
            telefono_cliente=request.POST.get('telefono_cliente'),
            red_social_cliente=request.POST.get('red_social_cliente'),
            descripcion_solicitada=descripcion,
            fecha_necesidad=request.POST.get('fecha_necesidad') or None,
            producto_referencia=producto_final,
            estado='SOLICITADO',
            estado_pago='PENDIENTE',
            plataforma_origen='SITIO_WEB'
        )

        lista_imagenes = request.FILES.getlist('imagenes_referencia')
        
        for imagen in lista_imagenes[:3]:
            ImagenReferencia.objects.create(pedido=nuevo_pedido, imagen=imagen)

        messages.success(request, "Pedido enviado correctamente")
        return redirect('seguimiento', token=nuevo_pedido.token_seguimiento)

    return render(request, 'formulario_solicitud.html', {'producto': producto_inicial})

def seguimiento(request, token):
    pedido = get_object_or_404(Pedido, token_seguimiento=token)
    imagenes = pedido.imagenes_referencia.all()
    
    context = {
        'pedido': pedido,
        'imagenes_referencia': imagenes
    }
    return render(request, 'seguimiento.html', context)